import { Heal1, Heal2, Heal3, Heal4, Heal5 } from './heal';

export var pickups = [];

export var pickupType = [
    undefined,//0
    Heal1,//1
    Heal2,//2
    Heal3,//3
    Heal4,//4
    Heal5,//5
]