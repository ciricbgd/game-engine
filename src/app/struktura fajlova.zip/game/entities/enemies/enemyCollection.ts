import { ScooterGirl } from './ScooterGirl';
import { FatGuy } from './FatGuy';

// List of enemy types
export var enemyType = [
    undefined,//0
    ScooterGirl,//1
    FatGuy,//2
];

export var enemies = [];//Array of existing enemies