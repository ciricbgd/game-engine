export var skipVideoIntro = true; // Skip video intro
export var skipVideoOutro = true; // Skip video outro
export var skipIntro = true; // Skip intro message of every level