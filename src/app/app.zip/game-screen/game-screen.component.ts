import { Component, OnInit } from '@angular/core';
import { Player, Enemy } from '../game/entities';
//import { Controls } from '../game/controls';
import { collides } from '../game/collision';
declare let $: any;

@Component({
  selector: 'app-game-screen',
  templateUrl: './game-screen.component.html',
  styleUrls: ['./game-screen.component.scss']
})
export class GameScreenComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
    //Draw canvas
    let sw = $("#container").width(); // Screen width
    let sh = $("#container").height(); // Screen height

    //Player canvas
    let canvas: any = document.querySelector("#gameScreen");
    canvas.width = sw;
    canvas.height = sh;
    let ctx = canvas.getContext("2d");

    //Test canvas
    let testCanvas: any = document.querySelector("#testScreen");
    testCanvas.width = sw;
    testCanvas.height = sh;
    let test = testCanvas.getContext("2d");

    //function to clear canvas
    function clearCanvas(screen) {
      screen.clearRect(0, 0, canvas.width, canvas.height);
    }
    //!Draw canvas

    // Entities - player, enemies, bosses
    const player = new Player('Player', sw / 2, sh / 2, sw / 10, sh / 7, ctx);
    player.draw();

    const enemy1 = new Enemy('Test Enemy', sw / 2, sh / 4, sw / 10, sh / 7, test);
    enemy1.boxColor = 'red';
    enemy1.draw();
    // ! Entities - player, enemies, bosses

    //Controls
    document.addEventListener('keydown', keyDownHandler, false);
    document.addEventListener('keyup', keyUpHandler, false);

    let rightPressed = false;
    let leftPressed = false;
    let upPressed = false;
    let downPressed = false;

    function keyDownHandler(event) {
      if (event.keyCode == 39) {
        rightPressed = true;

      }
      else if (event.keyCode == 37) {
        leftPressed = true;

      }
      if (event.keyCode == 40) {
        downPressed = true;

      }
      else if (event.keyCode == 38) {
        upPressed = true;

      }
    }

    function keyUpHandler(event) {
      if (event.keyCode == 39) {
        rightPressed = false;

      }
      else if (event.keyCode == 37) {
        leftPressed = false;

      }
      if (event.keyCode == 40) {
        downPressed = false;

      }
      else if (event.keyCode == 38) {
        upPressed = false;

      }
    }

    let lastPressed = [];

    function playerMove(accel) {
      if (rightPressed) {
        player.x += player.speed * accel;
        lastPressed[0] = 'right';
      }
      else if (leftPressed) {
        player.x -= player.speed * accel;
        lastPressed[0] = 'left';
      }

      if (downPressed) {
        player.y += player.speed * accel;
        lastPressed[1] = 'down';
      }
      else if (upPressed) {
        player.y -= player.speed * accel;
        lastPressed[1] = 'up';
      }
    }

    function slowDown(accel) {
      if (lastPressed[0] == 'right') { player.x += player.speed * accel; }
      else if (lastPressed[0] == 'left') { player.x -= player.speed * accel; }
      if (lastPressed[1] == 'down') { player.y += player.speed * accel; }
      else if (lastPressed[1] == 'up') { player.y -= player.speed * accel; }
    }

    function controlMove() {
      clearCanvas(ctx);

      if (!rightPressed && !leftPressed && !downPressed && !upPressed && player.accel > 0) {
        player.accel -= 12;
        slowDown(player.accel / 100);
      }
      else if ((rightPressed || leftPressed || downPressed || upPressed) && player.accel < 100) {
        player.accel = 100;
        playerMove(player.accel / 100);
        lastPressed = [];
      }
      else {
        playerMove(player.accel / 100);
      }

      if (player.accel < 0) { player.accel = 0; }
      if (player.accel > 100) { player.accel = 100; }

      //Border limitations
      if (player.x - player.w / 2 < 0) { player.x = player.w / 2 }
      if (player.x + player.w / 2 > sw) { player.x = sw - player.w / 2 }
      if (player.y - player.h / 2 < 0) { player.y = player.h / 2 }
      if (player.y + player.h / 2 > sh) { player.y = sh - player.h / 2 }
      //!Border limitations
      player.draw();

      //Collision detection
      console.log(collides(player, enemy1));

      requestAnimationFrame(controlMove);
    }
    controlMove();
    // ! Controls

    // Collision detection

    // function collisionDetection() {
    //   console.log(collides(player, enemy1));
    //   requestAnimationFrame(collisionDetection);
    // }
    // collisionDetection();

    // ! Collision detection
  }
}
