class Entity {
    name; x; y; w; h; speed; boxColor = "#AAAAAA"; screen; accel = 100;
    constructor(name, x, y, w, h, screen) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.screen = screen;
    }
    draw = function () {
        this.screen.fillStyle = this.boxColor;
        this.screen.fillRect(this.x - this.w / 2, this.y - this.h / 2, this.w, this.h);
    }
}

//Player
export class Player extends Entity {
    speed = 15;
}

//Enemies
export class Enemy extends Entity {
    speed = 8;
}