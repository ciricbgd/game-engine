export class Controls {
    rightPressed = false;
    leftPressed = false;
    upPressed = false;
    downPressed = false;

    keyDownHandler = function (event) {
        if (event.keyCode == 39) {
            this.rightPressed = true;
        }
        else if (event.keyCode == 37) {
            this.leftPressed = true;
        }
        if (event.keyCode == 40) {
            this.downPressed = true;
        }
        else if (event.keyCode == 38) {
            this.upPressed = true;
        }
    }

    keyUpHandler = function (event) {
        if (event.keyCode == 39) {
            this.rightPressed = false;
        }
        else if (event.keyCode == 37) {
            this.leftPressed = false;
        }
        if (event.keyCode == 40) {
            this.downPressed = false;
        }
        else if (event.keyCode == 38) {
            this.upPressed = false;
        }
    }

    constructor() {
        document.addEventListener('keydown', this.keyDownHandler, false);
        document.addEventListener('keyup', this.keyUpHandler, false);
    }

}

